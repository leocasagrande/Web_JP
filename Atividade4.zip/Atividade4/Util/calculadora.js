module.exports = {
    somar: function(a,b){
        return Number.parseInt(a)+Number.parseInt(b);
    },
    subtrair: function(a,b){
        return Number.parseInt(a)-Number.parseInt(b);
    },
    multiplicar: function(a,b){
        return Number.parseInt(a)*Number.parseInt(b);
    },
    dividir: function(a,b){
        return Number.parseInt(a)/Number.parseInt(b);
    }
}